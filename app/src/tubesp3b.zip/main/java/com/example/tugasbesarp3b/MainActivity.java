package com.example.tugasbesarp3b;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.tugasbesarp3b.FragmentHomepage;
import com.example.tugasbesarp3b.FragmentListener;
import com.example.tugasbesarp3b.R;
import com.example.tugasbesarp3b.gameplay;

public class MainActivity extends AppCompatActivity implements FragmentListener {

    private FragmentHomepage fragment1;
    private gameplay game;
    private FragmentManager fragmentManager;
    private menu_fragment menu;
    private FragmentGameOver over;
    private username userr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.fragment1 = FragmentHomepage.newInstance();
        this.game = gameplay.newInstance();
        this.menu=menu_fragment.newInstance();
        this.over=FragmentGameOver.newInstance();
        this.userr=username.newInstance();

        this.fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction ft = this.fragmentManager.beginTransaction();
        ft.add(R.id.fragment_container,this.fragment1);
        ft.commit();
    }

    @Override
    public void changePage(int page) {
        FragmentTransaction ft = this.fragmentManager.beginTransaction();
        if(page==1){
            ft.replace(R.id.fragment_container,this.fragment1)
                    .addToBackStack(null);
        }else if(page==2){
            ft.replace(R.id.fragment_container,this.game)
                    .addToBackStack(null);
        }
        else if(page==3){
            ft.replace(R.id.fragment_container,this.menu)
                    .addToBackStack(null);
        }
        else if(page==4){
            ft.replace(R.id.fragment_container,this.over)
                    .addToBackStack(null);
        }
        else if(page==5){
            ft.replace(R.id.fragment_container,this.userr)
                    .addToBackStack(null);
        }
        ft.commit();
    }
}