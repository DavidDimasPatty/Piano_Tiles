package com.example.tugasbesarp3b;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

public class username  extends Fragment implements View.OnClickListener{
    private FragmentListener listener;
    public EditText user;
    private Button play1;

    public static username newInstance(){
        username userre = new username();
        return userre;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.enterusername,container,false);
        this.user = view.findViewById(R.id.user);
        this.play1=view.findViewById(R.id.play_button);
        this.play1.setOnClickListener(this);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof  FragmentListener){
            this.listener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString()
                    + " must implement FragmentListener");
        }
    }
    @Override
    public void onClick(View v) {
        if(v==this.play1){
            listener.changePage(2);
        }

    }
}
