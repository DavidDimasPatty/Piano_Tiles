package com.example.tugasbesarp3b;

        import android.content.Context;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.TextView;

        import androidx.fragment.app.Fragment;

public class FragmentHomepage extends Fragment implements View.OnClickListener  {
    private FragmentListener listener;
    private Button btnPlay;
    private Button score1;

    public static FragmentHomepage newInstance(){
        FragmentHomepage fragment1 = new FragmentHomepage();
        return fragment1;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.homepage,container,false);
        this.btnPlay = view.findViewById(R.id.btn_play);
        this.score1=view.findViewById(R.id.score_page);
        btnPlay.setOnClickListener(this);
        score1.setOnClickListener(this);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof  FragmentListener){
            this.listener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString()
                    + " must implement FragmentListener");
        }
    }
    @Override
    public void onClick(View v) {
        if(v==this.btnPlay){
            listener.changePage(5);
        }
        if(v==this.score1){
            listener.changePage(3);
            Log.d("TAG", "onClick: ");
        }
    }

}
