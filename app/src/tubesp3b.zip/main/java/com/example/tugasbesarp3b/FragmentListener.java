package com.example.tugasbesarp3b;

public interface FragmentListener {
    void changePage(int page);
}
