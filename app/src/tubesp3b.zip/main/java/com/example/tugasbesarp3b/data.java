package com.example.tugasbesarp3b;

public class data {
    private String nama;
    private int score;

    public data(String nama, int score){
        this.nama= nama;
        this.score=score;

    }
    public String getNama(){  return this.nama; }
    public int getScore(){  return this.score; }
}