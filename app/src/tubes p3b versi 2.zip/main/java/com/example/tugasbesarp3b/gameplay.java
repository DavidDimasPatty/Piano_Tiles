package com.example.tugasbesarp3b;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.solver.widgets.Rectangle;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;

import java.util.Random;

public class gameplay extends Fragment implements View.OnClickListener {
    private FragmentListener listener;
    private Button start;
    private ImageView ivCanvas;
    private Button stop;
    private Bitmap mBitmap;
    public Canvas mCanvas;
    private Rect r;
    private TextView score;
    private username usere;

    private HandlerTest hantes;
    public static int x = 10;
    public static int y = 10;
    public static int z;
    Random random = new Random();

        public static gameplay newInstance(){
            gameplay game = new gameplay();
            return game;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
            View view = inflater.inflate(R.layout.game_play,container,false);
           // this.start = view.findViewById(R.id.btn_start);
          //  this.stop=view.findViewById(R.id.btn_stop);
            this.ivCanvas=view.findViewById(R.id.iv_canvas);
            this.score=view.findViewById(R.id.score);
            this.usere=username.newInstance();
            this.ivCanvas.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    int action = event.getAction();
                    int x = (int) event.getX();
                    int y = (int) event.getY();

                    if(x<150 || x>950) {
                        listener.changePage(4);
                        add(usere.k,Integer.parseInt(score.getText().toString()));
                        stop();
                    }
                    else {
                        switch (action) {
                            case MotionEvent.ACTION_DOWN:
                                score.setText(Integer.toString(Integer.parseInt(score.getText().toString()) + 10));
                                Log.d("TAG", "onTouch: " + x);
                                break;
                            case MotionEvent.ACTION_MOVE:

                                score.setText(Integer.toString(Integer.parseInt(score.getText().toString()) + 10));
                                break;
                            case MotionEvent.ACTION_UP:

                                score.setText(Integer.toString(Integer.parseInt(score.getText().toString()) + 10));
                                break;

                        }

                    }
                    return false;
                }
            });
            this.hantes= new HandlerTest(this);
            test();
//            start.setOnClickListener(this);
        //    stop.setOnClickListener(this);
            return view;
        }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof  FragmentListener){
            this.listener = (FragmentListener) context;
        } else{
            throw new ClassCastException(context.toString()
                    + " must implement FragmentListener");
        }
    }
    public void initiateCanvas2(int x, int y) {
        this.mBitmap = Bitmap.createBitmap(this.ivCanvas.getWidth(), this.ivCanvas.getHeight(), Bitmap.Config.ARGB_8888);
        this.ivCanvas.setImageBitmap(mBitmap);
        this.mCanvas = new Canvas(mBitmap);
        Paint paint = new Paint();
        int mBackgroundColor = ResourcesCompat.getColor(getResources(), R.color.Black, null);
        int mColorBall = ResourcesCompat.getColor(getResources(), R.color.colorAccent, null);
        mCanvas.drawColor(mBackgroundColor);
        paint.setColor(mColorBall);

        mCanvas.drawRect(450, x - 500, 650, y - 500, paint);
        mCanvas.drawRect(750, x - 900, 950, y - 900, paint);
        mCanvas.drawRect(350, x - 1400, 150, y - 1400, paint);
        mCanvas.drawRect(450, x - 1900, 650, y - 1900, paint);
        mCanvas.drawRect(750, x - 2400, 950, y - 2400, paint);
        mCanvas.drawRect(350, x - 2900, 150, y - 2900, paint);
        mCanvas.drawRect(450, x - 3400, 650, y - 3400, paint);
        mCanvas.drawRect(750, x - 3900, 950, y - 3900, paint);
        mCanvas.drawRect(350, x - 4400, 150, y - 4400, paint);
        mCanvas.drawRect(450, x - 4900, 650, y - 4900, paint);
        mCanvas.drawRect(750, x - 5400, 950, y - 5400, paint);
        mCanvas.drawRect(350, x - 5900, 150, y - 5900, paint);
        mCanvas.drawRect(450, x - 6400, 650, y - 6400, paint);
        mCanvas.drawRect(750, x - 6900, 950, y - 6900, paint);
        mCanvas.drawRect(450, x - 7400, 650, y - 7400, paint);
        mCanvas.drawRect(750, x - 7900, 950, y - 7900, paint);
        mCanvas.drawRect(350, x - 8400, 150, y - 8400, paint);
        mCanvas.drawRect(450, x - 8900, 650, y - 8900, paint);
        mCanvas.drawRect(750, x - 9400, 950, y - 9400, paint);
        mCanvas.drawRect(350, x - 9900, 150, y - 9900, paint);
        mCanvas.drawRect(450, x - 10400, 650, y - 10400, paint);
        mCanvas.drawRect(750, x - 10900, 950, y - 10900, paint);
        mCanvas.drawRect(350, x - 10400, 150, y - 10400, paint);
        mCanvas.drawRect(450, x - 10900, 650, y - 10900, paint);
        mCanvas.drawRect(750, x - 11400, 950, y - 11400, paint);
        mCanvas.drawRect(350, x - 11900, 150, y - 11900, paint);
        mCanvas.drawRect(450, x - 12400, 650, y - 12400, paint);
        mCanvas.drawRect(750, x - 12900, 950, y - 12900, paint);



        this.ivCanvas.invalidate();

    }

    @Override
    public void onClick(View v) {
        if (v == start) {
            test();
        }
        if(v==stop){
            listener.changePage(4);
            add(usere.k,Integer.parseInt(score.getText().toString()));
            Log.d("TAG", usere.k);
        }

    }

    public void add(String nama, int score){
        presenter.addToList(nama, score);
    }


    public void test() {
        ThreadTest objTest = new ThreadTest(this.hantes);
        objTest.start();
    }

    public void stop() {
        ThreadTest objTest = new ThreadTest(this.hantes);
        objTest.stop();
    }


}

